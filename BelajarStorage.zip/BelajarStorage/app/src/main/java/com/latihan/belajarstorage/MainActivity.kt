package com.latihan.belajarstorage

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Nama file SharedPreferences
    private val PREF_NAME = "MyUserPrefs"

    // Key untuk menyimpan nama
    private val KEY_NAMA = "KEY_NAMA_USER"

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi SharedPreferences
        sharedPreferences =
            getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        // Menghubungkan komponen XML
        val etNama = findViewById<EditText>(R.id.etNama)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)
        val btnMuat = findViewById<Button>(R.id.btnMuat)
        val btnHapus = findViewById<Button>(R.id.btnHapus)
        val tvHasil = findViewById<TextView>(R.id.tvHasil)

        // Tombol Simpan
        btnSimpan.setOnClickListener {

            val inputNama = etNama.text.toString().trim()

            if (inputNama.isNotEmpty()) {

                val editor = sharedPreferences.edit()

                editor.putString(KEY_NAMA, inputNama)

                editor.apply()

                Toast.makeText(
                    this,
                    "Data berhasil disimpan!",
                    Toast.LENGTH_SHORT
                ).show()

                etNama.text.clear()

            } else {

                Toast.makeText(
                    this,
                    "Silakan isi nama terlebih dahulu!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Tombol Muat
        btnMuat.setOnClickListener {

            val dataTersimpan =
                sharedPreferences.getString(
                    KEY_NAMA,
                    "Data tidak ditemukan"
                )

            tvHasil.text = dataTersimpan
        }

        // Tombol Hapus
        btnHapus.setOnClickListener {

            val editor = sharedPreferences.edit()

            editor.remove(KEY_NAMA)

            editor.apply()

            tvHasil.text = "[Data telah dihapus]"

            Toast.makeText(
                this,
                "Data berhasil dihapus!",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Memuat data otomatis saat aplikasi dibuka
        val namaAwal =
            sharedPreferences.getString(KEY_NAMA, null)

        if (namaAwal != null) {
            tvHasil.text = "Selamat datang kembali: $namaAwal"
        }
    }
}