package com.latihan.belajarstorage

class SplashScreenActivity {
}